# 新能源汽车销量预测系统源代码说明

团队名称：水豚噜噜儿队

本代码包为新能源汽车销量预测系统的完整实现，包含数据预处理、特征工程、模型训练、模型评估、预测推理、后端接口、前端展示和本地启动脚本。

## 1. 项目功能

系统支持以下功能：

- 车型历史销量查询；
- 未来月份销量预测；
- 品牌、能源类型、车型级别维度趋势分析；
- 模型评估指标展示；
- 本地浏览器页面交互体验；
- 脚本化重新训练与批量预测。


## 数据说明

代码包中的 `data/sample/sample_sales.csv` 为系统运行所需的最小化销量数据文件，由《新能源汽车政策福利研究_model_panel_v1_双检版.xlsx》中的 `model_panel_v1` 工作表提取新能源汽车样本后生成，仅保留模型训练和系统展示实际使用的 7 个字段：车型、品牌、月份、销量、能源类型、车型级别、价格区间。完整 Excel 工作簿中的政策、碳排放、能源价格等研究辅助数据未被本系统代码调用，因此不放入源代码包，避免提交未使用数据。

## 2. 目录结构

```text
新能源汽车销量预测系统_源代码/
├── backend/                后端接口、服务层与工具函数
├── frontend/               前端页面、样式和交互脚本
├── scripts/                数据处理、训练、评估和预测脚本
├── data/                   样例数据、清洗后数据和输出结果
├── models/                 训练后的模型文件和模型信息
├── config/                 配置文件和特征配置
├── docs/                   运行说明、接口说明、代码结构说明
├── tests/                  自检脚本
├── requirements.txt        Python 依赖
├── start.bat               Windows 启动脚本
└── start.sh                Linux/Mac 启动脚本
```

## 3. 环境依赖

建议环境：Python 3.9 及以上。

安装依赖：

```bash
pip install -r requirements.txt
```

## 4. 快速启动

Windows：

```bash
start.bat
```

Linux/Mac：

```bash
bash start.sh
```

启动后访问：

```text
http://127.0.0.1:8000
```

## 5. 脚本运行方式

预处理数据：

```bash
python scripts/preprocess.py
```

训练模型：

```bash
python scripts/train.py
```

评估模型：

```bash
python scripts/evaluate.py
```

生成指定车型预测结果：

```bash
python scripts/predict.py --vehicle "秦PLUS" --horizon 6
```

## 6. 数据格式

样例数据位于：

```text
data/sample/sample_sales.csv
```

字段包括：车型、品牌、月份、销量、能源类型、车型级别、价格区间。

如替换为新的数据，请保持字段含义一致。系统支持部分常见中文字段名自动映射。

## 7. 模型说明

系统使用梯度提升树回归模型进行车型级销量预测。模型输入包括时间特征、滞后销量特征、滚动统计特征、同比环比增长特征和车型属性特征；模型输出为未来月份预测销量。

## 8. 注意事项

- 不要删除 `data/sample/` 中的样例数据；
- 首次运行时会自动生成 `data/processed/`、`data/output/` 和 `models/` 中的文件；
- 启动脚本会重新训练模型以保证环境一致；
- 若需跳过训练，可直接运行 `python -m uvicorn backend.app:app --host 127.0.0.1 --port 8000`，但需确保模型文件已存在。
