from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from backend.service.data_service import (
    history_for_vehicle,
    list_vehicles,
    load_processed_data,
    overview,
    trend_by_dimension,
)
from backend.service.model_service import get_model_info
from backend.service.prediction_service import forecast
from backend.utils.path_utils import project_root

app = FastAPI(title='新能源汽车销量预测系统', version='1.0.0')
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)

ROOT = project_root()
FRONTEND_DIR = ROOT / 'frontend'

if (FRONTEND_DIR / 'src').exists():
    app.mount('/static', StaticFiles(directory=str(FRONTEND_DIR / 'src')), name='static')


@app.get('/')
def index():
    index_path = FRONTEND_DIR / 'src' / 'index.html'
    if not index_path.exists():
        raise HTTPException(status_code=404, detail='前端页面不存在。')
    return FileResponse(index_path)


@app.get('/api/health')
def health():
    return {'status': 'ok'}


@app.get('/api/overview')
def api_overview():
    try:
        df = load_processed_data()
        return overview(df)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.get('/api/vehicles')
def api_vehicles():
    try:
        df = load_processed_data()
        return {'vehicles': list_vehicles(df)}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.get('/api/history')
def api_history(vehicle_name: str = Query(..., description='车型名称')):
    try:
        df = load_processed_data()
        return {'vehicle_name': vehicle_name, 'history': history_for_vehicle(df, vehicle_name)}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.get('/api/predict')
def api_predict(
    vehicle_name: str = Query(..., description='车型名称'),
    horizon: int = Query(6, ge=1, le=24, description='预测月份数'),
):
    try:
        return forecast(vehicle_name, horizon)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.get('/api/evaluation')
def api_evaluation():
    try:
        return get_model_info()
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.get('/api/trend')
def api_trend(dimension: str = Query('brand_name', description='brand_name / energy_type / vehicle_level')):
    try:
        df = load_processed_data()
        return {'dimension': dimension, 'trend': trend_by_dimension(df, dimension)}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
