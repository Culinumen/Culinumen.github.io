from __future__ import annotations

import pandas as pd

from backend.utils.io_utils import read_json
from backend.utils.path_utils import resolve_path


def load_processed_data() -> pd.DataFrame:
    cfg = read_json(resolve_path('config/config.json'))
    path = resolve_path(cfg['processed_data_path'])
    if not path.exists():
        raise FileNotFoundError('清洗后数据不存在，请先运行 scripts/preprocess.py。')
    return pd.read_csv(path, encoding='utf-8-sig')


def list_vehicles(df: pd.DataFrame) -> list[dict]:
    cols = ['vehicle_name', 'brand_name', 'energy_type', 'vehicle_level', 'price_range']
    return (
        df[cols].drop_duplicates().sort_values(['brand_name', 'vehicle_name']).to_dict(orient='records')
    )


def history_for_vehicle(df: pd.DataFrame, vehicle_name: str) -> list[dict]:
    rows = df[df['vehicle_name'] == vehicle_name].sort_values('month')
    if rows.empty:
        raise ValueError(f'未找到车型：{vehicle_name}')
    return rows[['month', 'sales']].to_dict(orient='records')


def overview(df: pd.DataFrame) -> dict:
    return {
        'vehicle_count': int(df['vehicle_name'].nunique()),
        'brand_count': int(df['brand_name'].nunique()),
        'record_count': int(len(df)),
        'start_month': str(df['month'].min()),
        'end_month': str(df['month'].max()),
        'total_sales': int(df['sales'].sum()),
    }


def trend_by_dimension(df: pd.DataFrame, dimension: str = 'brand_name') -> list[dict]:
    allowed = {'brand_name', 'energy_type', 'vehicle_level'}
    if dimension not in allowed:
        raise ValueError(f'不支持的趋势分析维度：{dimension}')
    grouped = df.groupby(['month', dimension], as_index=False)['sales'].sum()
    grouped = grouped.rename(columns={dimension: 'category'})
    return grouped.sort_values(['month', 'category']).to_dict(orient='records')
