from __future__ import annotations

from functools import lru_cache

from backend.utils.io_utils import read_json
from backend.utils.model_utils import load_model
from backend.utils.path_utils import resolve_path


@lru_cache(maxsize=1)
def get_model():
    cfg = read_json(resolve_path('config/config.json'))
    return load_model(resolve_path(cfg['model_path']))


def get_model_info() -> dict:
    cfg = read_json(resolve_path('config/config.json'))
    path = resolve_path(cfg['model_info_path'])
    if path.exists():
        return read_json(path)
    return {'message': '模型信息文件不存在，请先运行 scripts/train.py。'}
