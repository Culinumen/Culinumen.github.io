from __future__ import annotations

from backend.service.data_service import load_processed_data
from backend.service.model_service import get_model
from backend.utils.model_utils import predict_vehicle


def forecast(vehicle_name: str, horizon: int = 6) -> dict:
    df = load_processed_data()
    model = get_model()
    history = df[df['vehicle_name'] == vehicle_name].sort_values('month')[['month', 'sales']].to_dict(orient='records')
    preds = predict_vehicle(model, df, vehicle_name, horizon)
    return {
        'vehicle_name': vehicle_name,
        'horizon': horizon,
        'history': history,
        'forecast': preds,
    }
