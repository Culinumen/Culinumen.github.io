from __future__ import annotations

from pathlib import Path
import pandas as pd

COLUMN_MAP = {
    '车型': 'vehicle_name',
    '车系': 'vehicle_name',
    '型号': 'vehicle_name',
    '品牌': 'brand_name',
    '品牌名称': 'brand_name',
    '月份': 'month',
    '销售月份': 'month',
    '统计月份': 'month',
    '销量': 'sales',
    '月销量': 'sales',
    '能源类型': 'energy_type',
    '动力类型': 'energy_type',
    '车型级别': 'vehicle_level',
    '级别': 'vehicle_level',
    '价格区间': 'price_range',
    '价格带': 'price_range',
}

REQUIRED_COLUMNS = [
    'vehicle_name', 'brand_name', 'month', 'sales',
    'energy_type', 'vehicle_level', 'price_range'
]


def read_sales_csv(path: str | Path) -> pd.DataFrame:
    """Read a sales CSV and normalize common Chinese field names to internal names."""
    source = Path(path)
    if not source.exists():
        raise FileNotFoundError(f'数据文件不存在：{source}')
    df = pd.read_csv(source, encoding='utf-8-sig')
    df = df.rename(columns={c: COLUMN_MAP.get(c, c) for c in df.columns})
    missing = [c for c in ['vehicle_name', 'month', 'sales'] if c not in df.columns]
    if missing:
        raise ValueError(f'缺少必要字段：{missing}')
    for col in REQUIRED_COLUMNS:
        if col not in df.columns:
            df[col] = '未知' if col != 'sales' else 0
    return df[REQUIRED_COLUMNS].copy()


def clean_sales_data(df: pd.DataFrame) -> pd.DataFrame:
    """Clean and aggregate source data to vehicle-month granularity."""
    out = df.copy()
    for col in ['vehicle_name', 'brand_name', 'energy_type', 'vehicle_level', 'price_range']:
        out[col] = out[col].fillna('未知').astype(str).str.strip()
        out[col] = out[col].replace({'': '未知', 'nan': '未知'})

    out['month'] = pd.to_datetime(out['month'], errors='coerce').dt.to_period('M').astype(str)
    out['sales'] = pd.to_numeric(out['sales'], errors='coerce')
    out = out.dropna(subset=['vehicle_name', 'month', 'sales'])
    out = out[out['sales'] >= 0]

    # Same vehicle and same month are aggregated to avoid duplicate records.
    agg_cols = ['vehicle_name', 'month']
    first_cols = ['brand_name', 'energy_type', 'vehicle_level', 'price_range']
    out = (
        out.groupby(agg_cols, as_index=False)
        .agg({'sales': 'sum', **{c: 'first' for c in first_cols}})
    )
    out['sales'] = out['sales'].round().astype(int)
    out = out.sort_values(['vehicle_name', 'month']).reset_index(drop=True)
    return out[REQUIRED_COLUMNS]


def save_processed(df: pd.DataFrame, path: str | Path) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(target, index=False, encoding='utf-8-sig')
