from __future__ import annotations

import numpy as np
import pandas as pd

NUMERIC_FEATURES = [
    'year', 'month_num', 'quarter', 'time_index',
    'sales_lag_1', 'sales_lag_3', 'sales_lag_6', 'sales_lag_12',
    'rolling_mean_3', 'rolling_mean_6', 'rolling_mean_12',
    'rolling_std_3', 'rolling_max_6', 'rolling_min_6',
    'mom_growth', 'yoy_growth'
]

CATEGORICAL_FEATURES = [
    'brand_name', 'energy_type', 'vehicle_level', 'price_range'
]

MODEL_FEATURES = NUMERIC_FEATURES + CATEGORICAL_FEATURES


def add_time_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    month_dt = pd.to_datetime(out['month'] + '-01', errors='coerce')
    out['month_dt'] = month_dt
    out['year'] = month_dt.dt.year
    out['month_num'] = month_dt.dt.month
    out['quarter'] = month_dt.dt.quarter
    global_min = month_dt.min()
    out['time_index'] = ((month_dt.dt.year - global_min.year) * 12 + month_dt.dt.month - global_min.month).astype(int)
    return out


def build_features(df: pd.DataFrame, training: bool = True) -> pd.DataFrame:
    """Build model features from vehicle-month sales data.

    Features are computed using shifted history, so the current month sales value
    is not leaked into the feature columns.
    """
    out = add_time_columns(df)
    out = out.sort_values(['vehicle_name', 'month_dt']).reset_index(drop=True)
    grouped = out.groupby('vehicle_name', group_keys=False)

    for lag in [1, 3, 6, 12]:
        out[f'sales_lag_{lag}'] = grouped['sales'].shift(lag)

    shifted = grouped['sales'].shift(1)
    out['rolling_mean_3'] = shifted.groupby(out['vehicle_name']).rolling(3, min_periods=1).mean().reset_index(level=0, drop=True)
    out['rolling_mean_6'] = shifted.groupby(out['vehicle_name']).rolling(6, min_periods=1).mean().reset_index(level=0, drop=True)
    out['rolling_mean_12'] = shifted.groupby(out['vehicle_name']).rolling(12, min_periods=1).mean().reset_index(level=0, drop=True)
    out['rolling_std_3'] = shifted.groupby(out['vehicle_name']).rolling(3, min_periods=2).std().reset_index(level=0, drop=True)
    out['rolling_max_6'] = shifted.groupby(out['vehicle_name']).rolling(6, min_periods=1).max().reset_index(level=0, drop=True)
    out['rolling_min_6'] = shifted.groupby(out['vehicle_name']).rolling(6, min_periods=1).min().reset_index(level=0, drop=True)

    out['mom_growth'] = (out['sales_lag_1'] - out['sales_lag_3']) / out['sales_lag_3'].replace(0, np.nan)
    out['yoy_growth'] = (out['sales_lag_1'] - out['sales_lag_12']) / out['sales_lag_12'].replace(0, np.nan)

    out[NUMERIC_FEATURES] = out[NUMERIC_FEATURES].replace([np.inf, -np.inf], np.nan)
    for col in CATEGORICAL_FEATURES:
        out[col] = out[col].fillna('未知').astype(str)

    if training:
        out['target_log'] = np.log1p(out['sales'].clip(lower=0))
        # Require at least one previous month of sales for supervised training.
        out = out.dropna(subset=['sales_lag_1']).reset_index(drop=True)
    return out


def make_future_feature_rows(history: pd.DataFrame, horizon: int) -> pd.DataFrame:
    """Create iterative future rows for a single vehicle.

    The caller may append predictions to history between iterations; this helper is
    mainly kept for batch cases. Online prediction uses build_one_future_row.
    """
    rows = []
    temp = history.copy()
    for step in range(1, horizon + 1):
        row = build_one_future_row(temp, step)
        rows.append(row)
        # Placeholder sales value; service code replaces it with predicted value.
        temp = pd.concat([temp, pd.DataFrame([{**row, 'sales': row.get('sales_lag_1', 0)}])], ignore_index=True)
    return pd.DataFrame(rows)


def build_one_future_row(history: pd.DataFrame, step: int = 1) -> dict:
    temp = history.copy().sort_values('month')
    last = temp.iloc[-1]
    next_month = (pd.to_datetime(str(last['month']) + '-01') + pd.DateOffset(months=step)).to_period('M').strftime('%Y-%m')
    base = pd.DataFrame([{
        'vehicle_name': last['vehicle_name'],
        'brand_name': last['brand_name'],
        'month': next_month,
        'sales': 0,
        'energy_type': last['energy_type'],
        'vehicle_level': last['vehicle_level'],
        'price_range': last['price_range'],
    }])
    combined = pd.concat([temp, base], ignore_index=True)
    feat = build_features(combined, training=False).iloc[-1]
    row = {col: feat[col] for col in MODEL_FEATURES + ['vehicle_name', 'month']}
    return row
