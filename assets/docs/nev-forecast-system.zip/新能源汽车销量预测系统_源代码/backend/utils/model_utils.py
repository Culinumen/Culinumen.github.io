from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from backend.utils.feature_utils import (
    CATEGORICAL_FEATURES,
    MODEL_FEATURES,
    NUMERIC_FEATURES,
    build_features,
    build_one_future_row,
)


def smape(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    denom = (np.abs(y_true) + np.abs(y_pred)) / 2.0
    mask = denom != 0
    if not mask.any():
        return 0.0
    return float(np.mean(np.abs(y_true[mask] - y_pred[mask]) / denom[mask]) * 100)


def mape_safe(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    mask = y_true != 0
    if not mask.any():
        return 0.0
    return float(np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100)


def build_pipeline(random_state: int = 42) -> Pipeline:
    numeric_pipeline = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler()),
    ])
    categorical_pipeline = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='most_frequent')),
        ('onehot', OneHotEncoder(handle_unknown='ignore')),
    ])
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numeric_pipeline, NUMERIC_FEATURES),
            ('cat', categorical_pipeline, CATEGORICAL_FEATURES),
        ]
    )
    model = GradientBoostingRegressor(
        random_state=random_state,
        n_estimators=220,
        learning_rate=0.045,
        max_depth=3,
        subsample=0.92,
        loss='squared_error',
    )
    return Pipeline(steps=[('preprocess', preprocessor), ('model', model)])


@dataclass
class TrainResult:
    model: Pipeline
    metrics: dict[str, Any]
    feature_frame: pd.DataFrame


def time_split_train_eval(processed: pd.DataFrame, validation_months: int = 6) -> TrainResult:
    features = build_features(processed, training=True)
    all_months = sorted(features['month'].unique())
    if len(all_months) <= validation_months + 3:
        raise ValueError('可用于训练的月份过少，无法完成时间切分验证。')
    valid_set = set(all_months[-validation_months:])
    train_df = features[~features['month'].isin(valid_set)].copy()
    valid_df = features[features['month'].isin(valid_set)].copy()

    model = build_pipeline()
    model.fit(train_df[MODEL_FEATURES], train_df['target_log'])

    pred_log = model.predict(valid_df[MODEL_FEATURES])
    pred = np.expm1(pred_log).clip(min=0)
    y_true = valid_df['sales'].to_numpy(dtype=float)

    lag_pred = valid_df['sales_lag_1'].fillna(valid_df['rolling_mean_3']).to_numpy(dtype=float)
    rolling_pred = valid_df['rolling_mean_3'].fillna(valid_df['sales_lag_1']).to_numpy(dtype=float)

    metrics = {
        'validation_months': sorted(valid_df['month'].unique()),
        'sample_count': int(len(valid_df)),
        'model': metric_block(y_true, pred),
        'baseline_lag_1': metric_block(y_true, lag_pred),
        'baseline_rolling_3': metric_block(y_true, rolling_pred),
        'feature_columns': MODEL_FEATURES,
    }
    return TrainResult(model=model, metrics=metrics, feature_frame=features)


def metric_block(y_true: np.ndarray, y_pred: np.ndarray) -> dict[str, float]:
    return {
        'MAE': round(float(mean_absolute_error(y_true, y_pred)), 2),
        'RMSE': round(float(np.sqrt(mean_squared_error(y_true, y_pred))), 2),
        'MAPE': round(mape_safe(y_true, y_pred), 2),
        'sMAPE': round(smape(y_true, y_pred), 2),
    }


def save_model(model: Pipeline, path: str | Path) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, target)


def load_model(path: str | Path) -> Pipeline:
    source = Path(path)
    if not source.exists():
        raise FileNotFoundError(f'模型文件不存在：{source}')
    return joblib.load(source)


def predict_vehicle(model: Pipeline, processed: pd.DataFrame, vehicle_name: str, horizon: int = 6) -> list[dict[str, Any]]:
    if horizon < 1 or horizon > 24:
        raise ValueError('预测周期应在 1 到 24 个月之间。')
    history = processed[processed['vehicle_name'] == vehicle_name].copy()
    if history.empty:
        raise ValueError(f'未找到车型：{vehicle_name}')
    history = history.sort_values('month').reset_index(drop=True)
    results = []
    temp = history.copy()
    for _ in range(horizon):
        row = build_one_future_row(temp, step=1)
        X = pd.DataFrame([{k: row[k] for k in MODEL_FEATURES}])
        sales_pred = max(0, int(round(float(np.expm1(model.predict(X)[0])))))
        month = row['month']
        results.append({
            'vehicle_name': vehicle_name,
            'month': month,
            'predicted_sales': sales_pred,
        })
        last = temp.iloc[-1]
        append_row = {
            'vehicle_name': vehicle_name,
            'brand_name': last['brand_name'],
            'month': month,
            'sales': sales_pred,
            'energy_type': last['energy_type'],
            'vehicle_level': last['vehicle_level'],
            'price_range': last['price_range'],
        }
        temp = pd.concat([temp, pd.DataFrame([append_row])], ignore_index=True)
    return results
