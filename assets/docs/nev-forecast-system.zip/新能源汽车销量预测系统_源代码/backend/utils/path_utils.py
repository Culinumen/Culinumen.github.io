from __future__ import annotations

from pathlib import Path


def project_root() -> Path:
    """Return the project root, independent of the current working directory."""
    return Path(__file__).resolve().parents[2]


def resolve_path(relative_path: str | Path) -> Path:
    path = Path(relative_path)
    if path.is_absolute():
        return path
    return project_root() / path
