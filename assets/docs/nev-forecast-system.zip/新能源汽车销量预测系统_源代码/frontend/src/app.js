const $ = (id) => document.getElementById(id);

async function getJson(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(await res.text());
  return await res.json();
}

function formatNumber(n) {
  return Number(n || 0).toLocaleString('zh-CN');
}

function renderOverview(data) {
  const items = [
    ['车型数量', data.vehicle_count],
    ['品牌数量', data.brand_count],
    ['样本记录', data.record_count],
    ['月份范围', `${data.start_month} — ${data.end_month}`],
  ];
  $('overviewCards').innerHTML = items.map(([label, value]) => `
    <div class="card"><div class="label">${label}</div><div class="value">${value}</div></div>
  `).join('');
}

function renderTable(table, headers, rows) {
  table.innerHTML = `
    <thead><tr>${headers.map(h => `<th>${h}</th>`).join('')}</tr></thead>
    <tbody>${rows.map(r => `<tr>${r.map(v => `<td>${v}</td>`).join('')}</tr>`).join('')}</tbody>
  `;
}

function drawLineChart(canvas, seriesList, options = {}) {
  const ctx = canvas.getContext('2d');
  const w = canvas.width, h = canvas.height;
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, w, h);
  const margin = { left: 68, right: 26, top: 28, bottom: 52 };
  const allPoints = seriesList.flatMap(s => s.values.map((y, i) => ({ x: i, y })));
  if (allPoints.length === 0) return;
  const maxY = Math.max(...allPoints.map(p => p.y), 1) * 1.12;
  const n = Math.max(...seriesList.map(s => s.labels.length));
  const plotW = w - margin.left - margin.right;
  const plotH = h - margin.top - margin.bottom;
  const colors = ['#1f5c93', '#5aa9dc', '#8bc5e8', '#94a3b8', '#2c7fb8', '#78b7db'];
  ctx.strokeStyle = '#d7e8f6';
  ctx.lineWidth = 1;
  ctx.fillStyle = '#667589';
  ctx.font = '12px Microsoft YaHei';
  for (let i = 0; i <= 5; i++) {
    const y = margin.top + plotH * i / 5;
    ctx.beginPath(); ctx.moveTo(margin.left, y); ctx.lineTo(w - margin.right, y); ctx.stroke();
    const label = Math.round(maxY * (1 - i / 5));
    ctx.fillText(formatNumber(label), 8, y + 4);
  }
  const xPos = (i) => margin.left + (n <= 1 ? 0 : plotW * i / (n - 1));
  const yPos = (val) => margin.top + plotH * (1 - val / maxY);
  seriesList.forEach((series, idx) => {
    ctx.strokeStyle = colors[idx % colors.length];
    ctx.lineWidth = idx === 0 ? 2.4 : 2;
    ctx.beginPath();
    series.values.forEach((val, i) => {
      const x = xPos(i), y = yPos(val);
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    });
    ctx.stroke();
    series.values.forEach((val, i) => {
      const x = xPos(i), y = yPos(val);
      ctx.beginPath(); ctx.arc(x, y, 3.2, 0, Math.PI * 2); ctx.fillStyle = colors[idx % colors.length]; ctx.fill();
    });
  });
  const labels = seriesList[0].labels;
  ctx.fillStyle = '#667589';
  const step = Math.max(1, Math.ceil(labels.length / 8));
  labels.forEach((label, i) => {
    if (i % step === 0 || i === labels.length - 1) ctx.fillText(label, xPos(i) - 18, h - 20);
  });
  let legendX = margin.left;
  seriesList.forEach((s, idx) => {
    ctx.fillStyle = colors[idx % colors.length];
    ctx.fillRect(legendX, 10, 18, 4);
    ctx.fillStyle = '#263445';
    ctx.fillText(s.name, legendX + 24, 15);
    legendX += 120;
  });
}

async function loadVehicles() {
  const data = await getJson('/api/vehicles');
  $('vehicleSelect').innerHTML = data.vehicles.map(v =>
    `<option value="${v.vehicle_name}">${v.vehicle_name}｜${v.brand_name}｜${v.energy_type}</option>`
  ).join('');
}

async function runPredict() {
  const vehicle = encodeURIComponent($('vehicleSelect').value);
  const horizon = $('horizonInput').value || 6;
  const data = await getJson(`/api/predict?vehicle_name=${vehicle}&horizon=${horizon}`);
  const history = data.history;
  const forecast = data.forecast;
  const labels = history.map(x => x.month).concat(forecast.map(x => x.month));
  const histValues = history.map(x => x.sales).concat(forecast.map(() => null));
  const predValues = history.map((x, i) => i === history.length - 1 ? x.sales : null).concat(forecast.map(x => x.predicted_sales));
  drawLineChart($('forecastChart'), [
    { name: '历史销量', labels, values: histValues.map(v => v === null ? NaN : v) },
    { name: '预测销量', labels, values: predValues.map(v => v === null ? NaN : v) },
  ].map(s => ({...s, values: fillMissing(s.values)})));
  renderTable($('forecastTable'), ['车型', '预测月份', '预测销量'],
    forecast.map(x => [x.vehicle_name, x.month, formatNumber(x.predicted_sales)]));
}

function fillMissing(values) {
  // Canvas line helper: replace gaps with previous point for continuity in this lightweight demo.
  let last = values.find(v => !Number.isNaN(v)) || 0;
  return values.map(v => {
    if (Number.isNaN(v)) return last;
    last = v; return v;
  });
}

async function loadMetrics() {
  const data = await getJson('/api/evaluation');
  const metrics = data.metrics || {};
  const rows = [
    ['上月销量法', metrics.baseline_lag_1],
    ['滚动均值法', metrics.baseline_rolling_3],
    ['主预测模型', metrics.model],
  ].map(([name, m]) => [name, m?.MAE ?? '-', m?.RMSE ?? '-', `${m?.MAPE ?? '-'}%`, `${m?.sMAPE ?? '-'}%`]);
  renderTable($('metricsTable'), ['评估对象', 'MAE', 'RMSE', 'MAPE', 'sMAPE'], rows);
}

async function loadTrend() {
  const dim = $('trendDim').value;
  const data = await getJson(`/api/trend?dimension=${dim}`);
  const rows = data.trend;
  const latestMonths = [...new Set(rows.map(r => r.month))].slice(-12);
  const filtered = rows.filter(r => latestMonths.includes(r.month));
  const byCat = {};
  filtered.forEach(r => {
    byCat[r.category] = byCat[r.category] || Object.fromEntries(latestMonths.map(m => [m, 0]));
    byCat[r.category][r.month] += r.sales;
  });
  const series = Object.entries(byCat).slice(0, 5).map(([cat, map]) => ({
    name: cat,
    labels: latestMonths,
    values: latestMonths.map(m => map[m] || 0),
  }));
  drawLineChart($('trendChart'), series);
}

async function init() {
  renderOverview(await getJson('/api/overview'));
  await loadVehicles();
  await Promise.all([runPredict(), loadMetrics(), loadTrend()]);
  $('predictBtn').addEventListener('click', runPredict);
  $('trendBtn').addEventListener('click', loadTrend);
}

init().catch(err => {
  console.error(err);
  alert('系统加载失败：' + err.message);
});
