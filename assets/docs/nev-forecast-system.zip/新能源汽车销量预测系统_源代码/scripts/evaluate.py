from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from backend.utils.io_utils import read_json, write_json
from backend.utils.model_utils import time_split_train_eval
from backend.utils.path_utils import resolve_path


def main() -> None:
    cfg = read_json(resolve_path('config/config.json'))
    processed = pd.read_csv(resolve_path(cfg['processed_data_path']), encoding='utf-8-sig')
    result = time_split_train_eval(processed, validation_months=6)
    write_json(resolve_path(cfg['evaluation_path']), result.metrics)
    print('模型评估完成：')
    for key in ['baseline_lag_1', 'baseline_rolling_3', 'model']:
        print(key, result.metrics[key])


if __name__ == '__main__':
    main()
