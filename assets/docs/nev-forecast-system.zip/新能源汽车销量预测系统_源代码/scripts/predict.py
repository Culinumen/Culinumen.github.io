from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from backend.utils.io_utils import read_json
from backend.utils.model_utils import load_model, predict_vehicle
from backend.utils.path_utils import resolve_path


def main() -> None:
    parser = argparse.ArgumentParser(description='新能源汽车车型销量预测')
    parser.add_argument('--vehicle', default=None, help='车型名称，不填则使用数据中的第一个车型')
    parser.add_argument('--horizon', type=int, default=6, help='预测月份数，默认 6')
    args = parser.parse_args()

    cfg = read_json(resolve_path('config/config.json'))
    processed = pd.read_csv(resolve_path(cfg['processed_data_path']), encoding='utf-8-sig')
    vehicle = args.vehicle or processed['vehicle_name'].iloc[0]
    model = load_model(resolve_path(cfg['model_path']))
    rows = predict_vehicle(model, processed, vehicle, args.horizon)
    out = pd.DataFrame(rows)
    output_path = resolve_path(cfg['prediction_output_path'])
    output_path.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(output_path, index=False, encoding='utf-8-sig')
    print(f'预测完成：{output_path}')
    print(out.to_string(index=False))


if __name__ == '__main__':
    main()
