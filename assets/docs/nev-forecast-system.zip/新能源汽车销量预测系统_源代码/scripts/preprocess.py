from __future__ import annotations

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from backend.utils.data_utils import clean_sales_data, read_sales_csv, save_processed
from backend.utils.io_utils import read_json
from backend.utils.path_utils import resolve_path


def main() -> None:
    cfg = read_json(resolve_path('config/config.json'))
    raw_path = resolve_path(cfg['raw_data_path'])
    processed_path = resolve_path(cfg['processed_data_path'])
    raw = read_sales_csv(raw_path)
    processed = clean_sales_data(raw)
    save_processed(processed, processed_path)
    print(f'预处理完成：{processed_path}，记录数：{len(processed)}')


if __name__ == '__main__':
    main()
