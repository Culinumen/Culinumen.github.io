from __future__ import annotations

import sys
from pathlib import Path
from datetime import datetime

import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from backend.utils.io_utils import read_json, write_json
from backend.utils.model_utils import save_model, time_split_train_eval
from backend.utils.path_utils import resolve_path


def main() -> None:
    cfg = read_json(resolve_path('config/config.json'))
    processed_path = resolve_path(cfg['processed_data_path'])
    if not processed_path.exists():
        raise FileNotFoundError('请先运行 python scripts/preprocess.py 生成清洗后数据。')
    processed = pd.read_csv(processed_path, encoding='utf-8-sig')
    result = time_split_train_eval(processed, validation_months=6)
    save_model(result.model, resolve_path(cfg['model_path']))
    info = {
        'model_name': 'GradientBoostingRegressor',
        'trained_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'data_range': {
            'start_month': str(processed['month'].min()),
            'end_month': str(processed['month'].max()),
            'vehicle_count': int(processed['vehicle_name'].nunique()),
            'record_count': int(len(processed)),
        },
        'metrics': result.metrics,
    }
    write_json(resolve_path(cfg['model_info_path']), info)
    write_json(resolve_path(cfg['evaluation_path']), result.metrics)
    print(f'模型训练完成：{resolve_path(cfg["model_path"])}')
    print(f'验证集指标：{result.metrics["model"]}')


if __name__ == '__main__':
    main()
