@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo [新能源汽车销量预测系统] 正在检查运行环境...
python --version >nul 2>nul
if errorlevel 1 (
  echo 未检测到 Python，请先安装 Python 3.9 或以上版本。
  pause
  exit /b 1
)
echo 正在安装依赖，如已安装会自动跳过...
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo 依赖安装失败，请检查网络或 Python 环境。
  pause
  exit /b 1
)
python scripts\preprocess.py
if errorlevel 1 pause && exit /b 1
python scripts\train.py
if errorlevel 1 pause && exit /b 1
echo 系统启动中，请在浏览器访问：http://127.0.0.1:8000
python -m uvicorn backend.app:app --host 127.0.0.1 --port 8000
pause
