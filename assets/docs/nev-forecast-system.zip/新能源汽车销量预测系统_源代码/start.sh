#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
echo "[新能源汽车销量预测系统] 正在检查运行环境..."
python3 --version
python3 -m pip install -r requirements.txt
python3 scripts/preprocess.py
python3 scripts/train.py
echo "系统启动中，请在浏览器访问：http://127.0.0.1:8000"
python3 -m uvicorn backend.app:app --host 127.0.0.1 --port 8000
