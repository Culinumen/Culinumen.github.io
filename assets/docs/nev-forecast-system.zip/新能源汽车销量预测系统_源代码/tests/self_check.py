from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))


def run(cmd: list[str]) -> None:
    print('> ' + ' '.join(cmd))
    subprocess.run(cmd, cwd=PROJECT_ROOT, check=True)


def check_files() -> None:
    required = [
        'README.md', 'requirements.txt', 'start.bat', 'start.sh',
        'backend/app.py', 'frontend/src/index.html', 'frontend/src/app.js', 'frontend/src/style.css',
        'scripts/preprocess.py', 'scripts/train.py', 'scripts/evaluate.py', 'scripts/predict.py',
        'data/sample/sample_sales.csv', 'config/config.json', 'config/feature_config.json',
    ]
    missing = [p for p in required if not (PROJECT_ROOT / p).exists()]
    if missing:
        raise AssertionError(f'缺少必要文件：{missing}')
    print('文件结构检查通过。')


def check_scripts() -> None:
    run([sys.executable, 'scripts/preprocess.py'])
    run([sys.executable, 'scripts/train.py'])
    run([sys.executable, 'scripts/evaluate.py'])
    run([sys.executable, 'scripts/predict.py', '--horizon', '3'])
    required_outputs = [
        'data/processed/processed_sales.csv',
        'models/sales_forecast_model.pkl',
        'models/model_info.json',
        'data/output/evaluation_metrics.json',
        'data/output/prediction_result.csv',
    ]
    missing = [p for p in required_outputs if not (PROJECT_ROOT / p).exists()]
    if missing:
        raise AssertionError(f'缺少运行输出：{missing}')
    print('脚本运行检查通过。')


def check_api() -> None:
    from fastapi.testclient import TestClient
    from backend.app import app

    client = TestClient(app)
    for path in ['/api/health', '/api/overview', '/api/vehicles', '/api/evaluation']:
        resp = client.get(path)
        assert resp.status_code == 200, (path, resp.status_code, resp.text)
    vehicles = client.get('/api/vehicles').json()['vehicles']
    assert vehicles, '车型列表为空'
    vehicle = vehicles[0]['vehicle_name']
    hist = client.get('/api/history', params={'vehicle_name': vehicle})
    assert hist.status_code == 200 and hist.json()['history'], '历史销量接口异常'
    pred = client.get('/api/predict', params={'vehicle_name': vehicle, 'horizon': 3})
    assert pred.status_code == 200, pred.text
    assert len(pred.json()['forecast']) == 3, '预测结果数量不正确'
    trend = client.get('/api/trend', params={'dimension': 'energy_type'})
    assert trend.status_code == 200 and trend.json()['trend'], '趋势接口异常'
    print('接口检查通过。')


def check_metrics() -> None:
    info_path = PROJECT_ROOT / 'models/model_info.json'
    info = json.loads(info_path.read_text(encoding='utf-8'))
    metrics = info['metrics']
    for block in ['baseline_lag_1', 'baseline_rolling_3', 'model']:
        for metric in ['MAE', 'RMSE', 'MAPE', 'sMAPE']:
            val = metrics[block][metric]
            assert isinstance(val, (int, float)), f'{block}.{metric} 不是数值'
            assert val >= 0, f'{block}.{metric} 小于 0'
    print('模型指标检查通过。')


def main() -> None:
    check_files()
    check_scripts()
    check_api()
    check_metrics()
    print('全部自检通过。')


if __name__ == '__main__':
    main()
